Readme for the Kibana Template
