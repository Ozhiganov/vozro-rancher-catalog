## Apache and Apaxy
Apaxy is a customisable theme for Apache, built to enhance the experience of browsing web directories. It uses the mod_autoindex Apache module—and some CSS—to override the default style of a directory listing.

#### Changelog

##### v0.1.0
* Initial version, based on [Apaxy](https://github.com/AdamWhitcroft/apaxy)
