## Atlassian JIRA server

Helps you setting up a jira server, running on a local or external database.

Lots of credits to https://github.com/blacklabelops with creating https://github.com/blacklabelops/jira !