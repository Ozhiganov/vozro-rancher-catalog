## Resilio Sync
Sync any folder to all your devices. Sync photos, videos, music, PDFs, docs
or any other file types to/from your mobile phone, laptop, or NAS.


#### Changelog

##### v0.1.0
* Initial version

#### Usage
Requires web port and data volume
