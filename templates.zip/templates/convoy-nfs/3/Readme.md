Note: Non-backwards compatible changes were introduced in v0.3.0. If upgrading, ensure you are currently on a version that is v0.3.0 or greater.
