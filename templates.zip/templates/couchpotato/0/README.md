## CouchPotato
Awesome PVR for usenet and torrents. Just fill in what you want to see and CouchPotato will add it to your "want to watch"-list. Every day it will search through multiple NZBs & Torrents sites, looking for the best possible match. If available, it will download it using your favorite download software.

#### Changelog

##### v0.1.0
* Initial version, based on [tssgery/strato-couchpotato](https://hub.docker.com/r/tssgery/strato-couchpotato/)

#### Usage
After installing, navigate to the WebUI and configure your settings
