# ELK configuration

*Simple configuration for a ELK Stack*
