# SandBox configuration

*Simple configuration for sandbox*

* File-Upload (port 4000 in the container)
 
