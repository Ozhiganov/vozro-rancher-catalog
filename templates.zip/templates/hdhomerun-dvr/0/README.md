## HDHomeRun DVR
The DVR reimagined.
Watch and Record all of your favorite live TV. Your way.


#### Changelog

##### v0.1.0
* Initial version

#### Usage
No configuration needed, but port 5004 will be exposed for this service automatically
