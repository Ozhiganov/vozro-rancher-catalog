## Headphones
Headphones is an automated music downloader for NZB and Torrent, written in
Python. It supports SABnzbd, NZBget, Transmission, µTorrent, Deluge and Blackhole.


#### Changelog

##### v0.1.0
* Initial version

#### Usage
After installing, navigate to the WebUI and configure your settings
