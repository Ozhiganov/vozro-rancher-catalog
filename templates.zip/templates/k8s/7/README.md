## Upgrade Kuberenetes Stack:  WARNING
This is not the newest version of the Kubernetes 1.3 template.  Please upgrade to latest template of Kubernetes 1.3.  
