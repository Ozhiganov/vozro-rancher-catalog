#[MeanShop](http://meanshop.com/)

Is a project by [Adrian Mejia](http://adrianmejia.com/)
which he describes as an:
"E-commerce Application built with the MEAN stack".
Visit it's [github page here.](https://github.com/amejiarosario/meanshop/)
Where Adrian maintains a set of links where you can purchase his book.

This is a rancher template that should enable you to quickly test it on
your rancher setup.

There are experimental versions of this template in this catalog [here](https://github.com/ohmydocker/ohmydocker-catalog) which implement
other setups.  Issues, PRs, etc are welcome there.
