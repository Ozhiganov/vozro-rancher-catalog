[MovieMasher](http://www.moviemasher.com/)

open source online video editor & encoding api

github:
https://github.com/moviemasher

rancher template using convoy for persistent data can be
found in this [catalog](https://github.com/ohmydocker/ohmydocker-catalog)
