## Mylar
Mylar is an automated Comic Book (cbr/cbz) downloader program heavily-based on the Headphones template and logic (which is also based on Sick-Beard).


#### Changelog

##### v0.1.0
* Initial version

#### Usage
After installing, navigate to the WebUI and configure your settings
