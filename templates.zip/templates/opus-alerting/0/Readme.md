# SandBox configuration

*Simple configuration for sandbox*

* Opus-Alerting (port 4000 in the container)
 
