# SandBox configuration

*Simple configuration for sandbox*

* 1 CouchBase instance
* 1 ElasticSearch instance
* 1 File Upload instance
* 1 Alerting instance
* 1 Opus-Core (port 3000 in the container)
* 1 Webtop instance
 
