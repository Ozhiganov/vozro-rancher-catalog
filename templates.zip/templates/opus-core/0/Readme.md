# Opus-Core with load-balancer

The aim is to deploy Opus-Core app with a basic configuration. The components will be installed on all hosts which have a label "opus-core=true".

Components:
* 1 load balancer for Opus-Core app
* 1 instance of Opus-Core

Prerequisite:
* 1 host (at least) with a label "opus-core=true"
