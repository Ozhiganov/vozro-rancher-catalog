## RaspberryPints
RaspberryPints (RPints) is a digital upgrade to the conventional chalkboard taplist, created just for the home brewer. Display your current beers on tap with a sleek, digital presentation. Manage your beers, recipes, kegs, and taps with our built-in tracking system.

#### Changelog

##### v0.1.0
* Initial version, based on [stratolinux/pints](https://github.com/stratolinux/pints)

#### Usage
After installing, navigate to the WebUI and configure your settings
