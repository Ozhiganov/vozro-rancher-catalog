## Rubygems-server
A rubygems server to host your own private gems

Expose the port 9292 using your HAproxy to let the gem-server be accessible to the outer world

The image is based on Geminabox: https://github.com/geminabox/geminabox
For more auth options see https://github.com/geminabox/geminaboxwiki/Http-Basic-Auth