## SABnzbd
Free and easy binary newsreader.

#### Changelog

##### v0.1.0
* Initial version, based on [stratolinux/sabnzbd](https://hub.docker.com/r/stratolinux/sabnzbd/)

#### Usage
After installing, navigate to the WebUI and configure your settings
